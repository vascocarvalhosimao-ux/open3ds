$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Build = Join-Path $Root "build-windows"
$Stage = Join-Path $Root "open3ds-0.10-windows-x86_64"

cmake -S $Root -B $Build -A x64 -DCMAKE_BUILD_TYPE=Release
cmake --build $Build --config Release

if (Test-Path $Stage) { Remove-Item $Stage -Recurse -Force }
New-Item -ItemType Directory -Path $Stage | Out-Null
New-Item -ItemType Directory -Path (Join-Path $Stage "dist") | Out-Null
New-Item -ItemType Directory -Path (Join-Path $Stage "plugins") | Out-Null
New-Item -ItemType Directory -Path (Join-Path $Stage "scripting") | Out-Null

$Exe = Join-Path $Build "Release/open3ds.exe"
if (!(Test-Path $Exe)) { $Exe = Join-Path $Build "open3ds.exe" }
if (!(Test-Path $Exe)) { throw "Executável não encontrado após a compilação." }
Copy-Item $Exe (Join-Path $Stage "Open3DS.exe")
@"
Open3DS 0.10-dev
Protótipo: ainda não executa jogos Nintendo 3DS.
Consulte README.md e docs/architecture.md no código-fonte.
"@ | Set-Content (Join-Path $Stage "README.txt")
Compress-Archive -Path $Stage -DestinationPath (Join-Path $Root "open3ds-0.10-windows-x86_64.zip") -Force
Write-Host "Pacote de protótipo criado. Não é ainda um emulador funcional."
