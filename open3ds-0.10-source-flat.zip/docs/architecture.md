# Arquitetura proposta

## Alvo de hardware

Helio P70: CPU ARM Cortex-A73/A53 e GPU Mali-G72 MP3. O alvo inicial deverá privilegiar
resolução interna reduzida, cache de shaders, compilação assíncrona, limites de memória e
um caminho gráfico que escolha Vulkan apenas quando o driver for estável; caso contrário,
OpenGL ES poderá ser mais compatível.

## Componentes que ainda faltam

- CPU: ARM11 MPCore e ARM946E-S, incluindo exceções, MMU e coprocessadores relevantes.
- GPU: comandos e rasterização PICA200, buffers, texturas e sincronização.
- Sistema: mapeamento de memória, IPC, serviços, temporizadores, interrupções e DMA.
- Dados: carregadores de executáveis e imagens de jogo, com suporte apenas a dados obtidos legalmente.
- Periféricos: ecrãs duplos, touchscreen, botões, áudio e estados de gravação.

## Critérios de desempenho

Não assumir que "Mali" implica compatibilidade Vulkan. Consultar as extensões reportadas
pelo dispositivo e testar o driver. Medir FPS, latência, picos de RAM e stutter em cenas
reprodutíveis antes de ativar otimizações.
