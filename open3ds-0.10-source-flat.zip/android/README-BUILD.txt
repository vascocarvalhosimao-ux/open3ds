Open3DS Android — projeto-base, não um APK pronto.

Abrir esta pasta no Android Studio, instalar o Android SDK e sincronizar o Gradle.
Depois usar Build > Build Bundle(s) / APK(s) > Build APK(s).

Este projeto ainda não contém o núcleo de emulação 3DS e não executa jogos.
